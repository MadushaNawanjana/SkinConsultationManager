import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.*;

public class WestminsterSkinConsultationManager implements SkinConsultationManager {

    //array list for doctors list
    public List<Doctor> doctorList = new ArrayList<>();

    Scanner scanner = new Scanner(System.in);
    private final int mDoctors = 10;
    //private boolean isSort;


    //method to add new doctors
    @Override
    public void addDoctor() {
        if (doctorList.size() < mDoctors){
            System.out.println("Enter the name of the doctor: ");
            String Name = scanner.next();

            System.out.println("Enter the surname of the doctor: ");
            String surName = scanner.next();

            System.out.println("Enter the date of birth of the doctor (in the format yyyy-mm-dd): ");
            String dob = scanner.next();
            LocalDate birthday = LocalDate.parse(dob);

            System.out.println("Enter the mobile no of the doctor: ");
            String mobileNo = scanner.next();

            System.out.println("Enter Doctor Medical Licence Number: ");
            String medicalLicenceNumber = scanner.next();

            System.out.println("Enter Doctor Speciality (cosmetic dermatology, medical dermatology, paediatric \n" +
                    "dermatology): ");
            String specialisation = scanner.next();

            Doctor doctor = new Doctor(Name, surName, birthday, mobileNo, medicalLicenceNumber, specialisation);
            doctorList.add(doctor);
        }

        else {
            System.out.println("Our skin consultation center can allocate a maximum of " +  mDoctors + "doctors.");
        }

    }

    //method to delete doctors
    @Override
    public void deleteDoctor() {
        System.out.println("Enter Medical Licence Number to delete doctors: ");
        int medicalLicenceNumber = scanner.nextInt();

        int deleteDoctors = -1;

        for (int i = 0; i < doctorList.size(); i++){
            if (Objects.equals(doctorList.get(i).getMedicalLicenceNumber(), medicalLicenceNumber));
            {
                deleteDoctors = i;
                break;
            }
        }

        if (deleteDoctors != -1){
            Doctor doctor = doctorList.remove(deleteDoctors);

            System.out.println("|==== Deleted ====|");
            System.out.println();
            System.out.println(doctor.getMedicalLicenceNumber() + " - " + doctor.getName());
            System.out.println();
            System.out.println("Total number of doctors: " + doctorList.size());
        }

        else {
            System.out.println("No doctors");
        }
    }

    @Override
    public void showDoctorList(boolean isSort) {

    }


    //method to print list details of doctors
    @Override
    public void showDoctorsList() {
        System.out.println("==== Doctors List ====");


        //sorting doctor list according to doctor surname
        Collections.sort(doctorList, new Comparator<Doctor>() {
            @Override
            public int compare(Doctor d1, Doctor d2) {
                return d1.getSurname().compareTo(d2.getSurname());
            }
        });

        for (Doctor doctor : doctorList){
            System.out.println("Name - " + doctor.getName() + ", Surname - " + doctor.getSurname()
                    + ", DOB - " + doctor.getDateOfBirth() +
                    ", Mobile - " + doctor.getMobileNo() + ", MLN - " + doctor.getMedicalLicenceNumber()
                    + ", Specialisation - " + doctor.getSpecialisation() );
        }
    }

    @Override
    public void showDoctorsList(boolean isSort) {

    }


    /**
     * Method to the menu
     */
    private void showOptions() {
        while (true) {
            System.out.println("******** Welcome to our Skin Consultation Center ********");
            System.out.println("=========================================================");
            System.out.println("            \t1. Add a doctor");
            System.out.println("            \t2. Delete a doctor");
            System.out.println("            \t3. Print the list of doctors");
            System.out.println("            \t4. Save");
            System.out.println("            \t5. Exit");
            System.out.println("=========================================================");
            break;
        }

    }


    //method to save information to file
    public void save() throws IOException{
        try{
            StringBuilder stringBuilder = new StringBuilder();
            for (Doctor doctor : doctorList){
                stringBuilder.append("Name - " + doctor.getName()+", Surname - " +doctor.getSurname()
                        +", DOB - " +doctor.getDateOfBirth()+", MobileNo - " +
                        doctor.getMobileNo() + ", MLN - "
                + doctor.getMedicalLicenceNumber()+", Specialisation - " + doctor.getSpecialisation() + " \n\n");

            }
            Path fileName = Path.of("doctor.txt");
            Files.writeString(fileName, stringBuilder);
        }

        catch (IOException e){
            System.out.println("Failed" + e.getMessage());
        }
    }
/**
    public void data(){
        try {
            Path fileName = Path.of("./doctor.txt");
            String file = Files.readString(fileName);
        } catch (IOException e) {
            System.out.println("Can't read" + e.getMessage());
        }
        this.doctorList = new ArrayList<>();
        Doctor doctor = new Doctor("Asanka", "Perera", 20011012, 0115423, 4528, "Skin");
        this.doctorList.add(doctor);
    }*/


    public static void main(String[] args) throws IOException, ClassNotFoundException {

        WestminsterSkinConsultationManager westminsterSkinConsultationManager = new WestminsterSkinConsultationManager();


        while (true) {

            westminsterSkinConsultationManager.showOptions();
            try {
                Scanner scanner = new Scanner(System.in);
                System.out.println("Enter your option: ");
                int option = scanner.nextInt();



                switch (option) {
                    case 1:
                        //adding doctors

                        westminsterSkinConsultationManager.addDoctor();

                        break;


                    case 2:

                        westminsterSkinConsultationManager.deleteDoctor();


                    case 3:

                        westminsterSkinConsultationManager.showDoctorsList();

                        break;

                    case 4:

                        westminsterSkinConsultationManager.save();
                        break;

                    case 5:  //exit
                        System.exit(1);
                        break;


                    default:
                        System.out.println("Try Again");
                        break;
                }

                System.out.println();


    }
            catch (Exception e) {
                System.out.println("Try Again!!!");
            }
        }
    }
}
