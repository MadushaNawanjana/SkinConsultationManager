import javax.swing.*;
import java.awt.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Main {
    private WestminsterSkinConsultationManager westminsterSkinConsultationManager = new WestminsterSkinConsultationManager();

    public static void main(String[] args){
        new Main().start();
    }

    public void start() {
        // Create frame
        JFrame frame = new JFrame("Westminster Skin Consultation Manager");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create table model
        DOctorTableModel tableModel = new DOctorTableModel();

        // Create table
        JTable table = new JTable(tableModel);

        // Add table to scroll pane
        JScrollPane scrollPane = new JScrollPane(table);

        // Add scroll pane to frame
        frame.add(scrollPane, BorderLayout.CENTER);

        // Create panel for booking consultations
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2, 10, 10));

        // Create text fields and labels
        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField();
        JLabel surnameLabel = new JLabel("Surname:");
        JTextField surnameField = new JTextField();
        JLabel dobLabel = new JLabel("Date of Birth:");
        JTextField dobField = new JTextField();
        JLabel mobileNumberLabel = new JLabel("Mobile Number:");
        JTextField mobileNumberField = new JTextField();

        // Add text fields and labels to panel
        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(surnameLabel);
        panel.add(surnameField);
        panel.add(dobLabel);
        panel.add(dobField);
        panel.add(mobileNumberLabel);
        panel.add(mobileNumberField);

        // Create book consultation button
        JButton bookButton = new JButton("Book Consultation");
        bookButton.addActionListener(e -> {
            String name = nameField.getText();
            String surname = surnameField.getText();
            String dobString = dobField.getText();
            String mobileNumber = mobileNumberField.getText();

            // Parse date of birth
            DateFormat df = new SimpleDateFormat("dd/MM/yyyy");

});
    }
}