import javax.swing.table.AbstractTableModel;
import java.util.List;

public class DOctorTableModel extends AbstractTableModel {

    public List<Doctor> doctorList;

    public DOctorTableModel (List<Doctor>doctorList){
        this.doctorList = doctorList;
    }

    public DOctorTableModel() {

    }

    @Override
    public int getRowCount() {
        return doctorList.size();
    }

    @Override
    public int getColumnCount() {
        return 6;
    }


    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Doctor doctor = doctorList.get(rowIndex);

        switch (columnIndex){
            case 0:
                return doctor.getName();

            case 1:
                return doctor.getSurname();

            case 2:
                return doctor.getDateOfBirth();

            case 3:
                return doctor.getMobileNo();

            case 4:
                return doctor.getMedicalLicenceNumber();

            case 5:
                return doctor.getSpecialisation();

            default:
                return "";
        }
    }
}
