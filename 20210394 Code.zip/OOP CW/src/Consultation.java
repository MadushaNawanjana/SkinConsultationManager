import java.time.LocalDate;

public class Consultation {

    private Doctor doctor;
    private Patient patient;
    private LocalDate date;
    private LocalDate time;
    private double cost;
    private String notes;


    //constructor
    public Consultation(LocalDate date, LocalDate time, double cost, String notes)
    {
        this.date = date;
        this.time = time;
        this.cost = cost;
        this.notes = notes;
    }

    public Consultation(String patient, String doctor, String date, String time) {
    }


    //getters and setters
    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public LocalDate getTime() {
        return time;
    }

    public void setTime(LocalDate time) {
        this.time = time;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Doctor getDoctor()
    {
        return doctor;
    }

    public void setDoctor(Doctor doctor)
    {
        this.doctor = doctor;
    }

    public Patient getPatient()
    {
        return patient;
    }

    public void setPatient(Patient patient)
    {
        this.patient = patient;
    }
}
