import java.time.LocalDate;

//Person class
public class Person {

    private String name;
    private String surname;
    private LocalDate dateOfBirth;
    private String mobileNo;


    //constructor
    public Person(String name, String surName, LocalDate dob, String mobileNo) {
        this.name = name;
        this.surname = surName;
        this.dateOfBirth = dob;
        this.mobileNo = mobileNo;
    }

    public Person() {

    }


    //getters and setters
    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getSurname()
    {
        return surname;
    }

    public void setSurName(String surname)
    {
        this.surname = surname;
    }

    public LocalDate getDateOfBirth()
    {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth)
    {
        this.dateOfBirth = dateOfBirth;
    }

    public String getMobileNo()
    {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo)
    {
        this.mobileNo = mobileNo;
    }
}
