//class Patient
public class Patient extends Person {

    private int uniqueId;

    public Patient(int uniqueId)
    {
        super();
        this.uniqueId = uniqueId;
    }


    //getters and setters
    public int getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(int uniqueId) {
        this.uniqueId = uniqueId;
    }
}
