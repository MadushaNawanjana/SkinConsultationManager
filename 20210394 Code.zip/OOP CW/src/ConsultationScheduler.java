import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class ConsultationScheduler extends JFrame {

    //text field for user input
    private JTextField patientField;
    private JTextField doctorField;
    private JTextField dateField;
    private JTextField timeField;

    //table to display consultations
    private JTable consultationTable;
    private DefaultTableModel tableModel;

    //list to store consultations
    private List<Consultation> consultations;

    public String ConsultationScheduler() {
        //create text fields
        patientField = new JTextField(20);
        doctorField = new JTextField(20);
        dateField = new JTextField(20);
        timeField = new JTextField(20);

        // create table to display consultations
        tableModel = new DefaultTableModel(new String[]{"Patient", "Doctor", "Date", "Time"}, 0);
        consultationTable = new JTable(tableModel);

        //create button
        JButton bookButton = new JButton("Book Consultation");
        bookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String patient = patientField.getText();
                String doctor = doctorField.getText();
                String date = dateField.getText();
                String time = timeField.getText();

                //check availability of the doctor
                boolean isAvailable = checkAvailability(doctor, date, time);

                if (isAvailable) {
                    //create consultation and add to list
                    Consultation consultation = new Consultation(patient, doctor, date, time);
                    consultations.add(consultation);

                    tableModel.addRow(new Object[]{patient, doctor, date, time});

                } else {
                    //select random doctor who is available
                    String availableDoctor = selectRandomDoctor(date, time);

                    //create consultation and add to list
                    Consultation consultation = new Consultation(patient, availableDoctor, date, time);
                    consultations.add(consultation);

                    //update table
                    tableModel.addRow(new Object[]{patient, availableDoctor, date, time});

                    //show message to user
                    JOptionPane.showMessageDialog(ConsultationScheduler.this, "Doctor is not" +
                            "available, Consultation booked with " + availableDoctor);
                }
            }

            private String selectRandomDoctor(String date, String time) {
                return date;
            }

            private boolean checkAvailability(String doctor, String date, String time) {
                return false;
            }
        });

        // create panel for input fields and button
        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Patient:"));
        inputPanel.add(patientField);
        inputPanel.add(new JLabel("Doctor:"));
        inputPanel.add(doctorField);
        inputPanel.add(new JLabel("Date:"));
        inputPanel.add(dateField);
        inputPanel.add(new JLabel("Time:"));
        inputPanel.add(timeField);
        inputPanel.add(bookButton);

        // add input panel and table to frame
        add(inputPanel, BorderLayout.NORTH);
        add(new JScrollPane(consultationTable), BorderLayout.CENTER);

        // set frame properties
        setTitle("Consultation Scheduler");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);

        // method to check availability of a doctor
        boolean checkAvailability;
        //Object String;
        String doctor = null;
        String date = null;
        String time = null;
        {
            // check availability in list of consultations
            for (Consultation c : consultations) {
                if (c.getDoctor().equals(doctor) && c.getDate().equals(date) && c.getTime().equals(time)) {
                    return String.valueOf(false);
                }
            }
            return String.valueOf(true);
        }
    }
}
/**
        // method to select a random doctor who is available
        //private String selectRandomDoctor(String date, String time) {

        // create list of available doctors
        List<String> availableDoctors = new ArrayList<>();
        for (Consultation c : consultations) {
            if (checkAvailability(c.getDoctor(), date, time)) {
                availableDoctors.add(String.valueOf(c.getDoctor()));
            }
        }

        // select random doctor from list
        if (availableDoctors.size() > 0) {
            Random rnd = new Random();
            int index = rnd.nextInt(availableDoctors.size());
            return availableDoctors.get(index);
        } else {
            return "No doctors available";
        }
    }


    private boolean checkAvailability(Doctor doctor, String date, String time) {
        return false;
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ConsultationScheduler().setVisible(true);
            }
        });
    }
}

class Consultation2 {
    private String patient;
    private String doctor;
    private String date;
    private String time;

    public Consultation2(String patient, String doctor, String date, String time) {
        this.patient = patient;
        this.doctor = doctor;
        this.date = date;
        this.time = time;
    }

    public String getPatient() {
        return patient;
    }

    public String getDoctor() {
        return doctor;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }
}*/


