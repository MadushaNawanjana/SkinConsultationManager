import java.time.LocalDate;

/**
 * subclass Doctor
 */
public class Doctor  extends Person implements Comparable<Doctor>{


          private String medicalLicenceNumber;
          private String specialisation;


          //constructor
    public Doctor(String Name, String surName, LocalDate dob, String mobileNo, String medicalLicenceNumber, String specialisation)
    {
        super(Name, surName, dob, mobileNo);
        this.medicalLicenceNumber = medicalLicenceNumber;
        this.specialisation = specialisation;
    }


    @Override
    public int compareTo(Doctor o) {
        return 0;
    }


    //getters and setters
    public String getMedicalLicenceNumber() {
        return medicalLicenceNumber;
    }

    public String getSpecialisation() {
        return specialisation;
    }

    public void setMedicalLicenceNumber(String medicalLicenceNumber) {
        this.medicalLicenceNumber = medicalLicenceNumber;
    }

    public void setSpecialisation(String specialisation) {
        this.specialisation = specialisation;
    }


}
