import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class GUI extends JFrame {

        //List<Doctor> doctorList = null;
        //DoctorTableModel doctorTableModel = new DoctorTableModel(doctorList);

        //creating the table
        //JTable jTable = new JTable(doctorTableModel);

        //adding the table to a scroll pane
        //JScrollPane jScrollPane = new JScrollPane(jTable);

        //adding the scroll pane to a frame
        /**
        JFrame jFrame = new JFrame("Skin Consultation Center");
        Button button = new Button();
        //jFrame.add(jScrollPane);
        jFrame.setSize(400, 300);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(jFrame.EXIT_ON_CLOSE);
        jFrame.getContentPane().setBackground(new Color(0x123456));

        JLabel jblName = new JLabel("Westminster Skin Consultation Center");
         */

        private JTable doctorsTable;

        public GUI() {
            JFrame frame = new JFrame("Westminster Skin Consultation Manager");
            JPanel panel = new JPanel();
            String[] columnNames = {"Name", "Surname", "Date of Birth", "Mobile Number", "Medical License Number", "Specialisation"};
            List<Doctor> doctorList = new ArrayList<>();
            Object[][] data = new Object[doctorList.size()][6];
            for (int i = 0; i < doctorList.size(); i++) {
                Doctor doctor = doctorList.get(i);
                data[i][0] = doctor.getName();
                data[i][1] = doctor.getSurname();
                data[i][2] = doctor.getDateOfBirth();
                data[i][3] = doctor.getMobileNo();
                data[i][4] = doctor.getMedicalLicenceNumber();
                data[i][5] = doctor.getSpecialisation();
            }

            JTable table = new JTable(data, columnNames);
            table.setBackground(new Color(182, 239, 237));
            panel.add(new JScrollPane(table));
            frame.add(panel);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setVisible(true);
            //setTitle("Westminster Skin Consultation Manager");
            frame.setSize(550, 500);
            frame.setLocationRelativeTo(null);
            JList<Doctor> doctorJList = new JList<>();
            frame.add(new JScrollPane(doctorJList), BorderLayout.CENTER);
            frame.setBackground(new Color(0x4578AB));

        }

        public static void main(String[] args){
            GUI gui = new GUI();
            gui.setVisible(true);

            GUImain guImain = new GUImain();

            PatientManager patientManager = new PatientManager();
            patientManager.setVisible(true);

            JFrame frame = new JFrame();
            frame.setVisible(true);


        }


}
