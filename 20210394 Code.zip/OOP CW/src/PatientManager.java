import javax.swing.*;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PatientManager extends JFrame implements ActionListener {

    private JLabel nameLabel;
    private JTextField nameField;
    private JLabel surnameLabel;
    private JTextField surnameField;
    private JLabel dobLabel;
    private JTextField dobField;
    private JLabel mobileLabel;
    private JTextField mobileField;
    private JLabel idLabel;
    private JTextField idField;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;
    private JButton viewButton;
    private JTable patientTable;
    private PatientTableModel tableModel;

    public PatientManager() {
        // set up components and layout
        nameLabel = new JLabel("Name:");
        nameField = new JTextField(20);
        surnameLabel = new JLabel("Surname:");
        surnameField = new JTextField(20);
        dobLabel = new JLabel("Date of birth (dd-mm-yyyy):");
        dobField = new JTextField(20);
        mobileLabel = new JLabel("Mobile number:");
        mobileField = new JTextField(20);
        idLabel = new JLabel("ID:");
        idField = new JTextField(20);
        addButton = new JButton("Add");
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
        viewButton = new JButton("View");

        // add action listeners
        addButton.addActionListener(this);
        editButton.addActionListener(this);
        deleteButton.addActionListener(this);
        viewButton.addActionListener(this);

        // create table model and table
        tableModel = new PatientTableModel();
        patientTable = new JTable((TableModel) tableModel);

        // set up layout
        setLayout(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();

        // add name label and field
        gc.gridx = 0;
        gc.gridy = 0;
        gc.weightx = 1;
        gc.weighty = 1;
        gc.fill = GridBagConstraints.NONE;
        gc.anchor = GridBagConstraints.LINE_END;
        gc.insets = new Insets(5, 5, 5, 5);
        add(nameLabel, gc);

        gc.gridx = 1;
        gc.gridy = 0;
        gc.weightx = 1;
        gc.weighty = 1;
        gc.fill = GridBagConstraints.NONE;
        gc.anchor = GridBagConstraints.LINE_START;
        gc.insets = new Insets(5, 5, 5, 5);
        add(nameField, gc);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

    }

    private class PatientTableModel {

    }
}
