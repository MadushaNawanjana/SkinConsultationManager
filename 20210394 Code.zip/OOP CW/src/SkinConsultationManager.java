import java.io.IOException;

public interface SkinConsultationManager
{
    public void addDoctor();


    void deleteDoctor();

    void showDoctorList(boolean isSort);

    public void showDoctorsList();


    void showDoctorsList(boolean isSort);

}
