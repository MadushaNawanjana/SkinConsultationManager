import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Button extends JFrame implements ActionListener {

    public Button(){

        //create the button
        JButton jButton = new JButton("View Doctor Details");

        //add the button
        add(jButton);

        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //perform some when the button clicked
                System.out.println("Viewing...");
            }
        });

        //set the size and title of the gui
        setSize(300, 300);
        setTitle("Doctor Details");

        //show the gui
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
