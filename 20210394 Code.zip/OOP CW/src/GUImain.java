import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class GUImain {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Westminster Skin Consultation Center");

        JPanel panel = new JPanel();

        JButton button1 = new JButton("View Doctors Details");
        panel.add(button1);

        JButton button2 = new JButton("Add Patient Details");
        panel.add(button2);

        JButton button3 = new JButton("Enter");
        panel.add(button3);

        frame.add(panel);

        frame.setSize(300, 100);
        frame.setVisible(true);


        //create an  ActionListner for the Button1
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] columnNames = {"Name", "Surname", "Date of Birth", "Mobile Number", "Medical License Number", "Specialisation"};
                List<Doctor> doctorList = new ArrayList<>();
                Object[][] data = new Object[doctorList.size()][6];
                for (int i = 0; i < doctorList.size(); i++) {
                    Doctor doctor = doctorList.get(i);
                    data[i][0] = doctor.getName();
                    data[i][1] = doctor.getSurname();
                    data[i][2] = doctor.getDateOfBirth();
                    data[i][3] = doctor.getMobileNo();
                    data[i][4] = doctor.getMedicalLicenceNumber();
                    data[i][5] = doctor.getSpecialisation();
                }

                JTable table = new JTable(data, columnNames);
                table.setBackground(new Color(15, 56, 78));
                panel.add(new JScrollPane(table));
                frame.add(panel);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.pack();
                frame.setVisible(true);
            }
        });

        List<Doctor> doctorList = new ArrayList<>();
        DOctorTableModel tableModel = new DOctorTableModel(doctorList);


    }
}
