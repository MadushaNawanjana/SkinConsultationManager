import javax.swing.*;
import java.awt.*;
import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddingPatients extends JFrame {

    public AddingPatients(){
        JPanel panel = new JPanel();
        setLayout(new FlowLayout(FlowLayout.LEFT, 10, 20));

        //add labels and text fields to the frame
        add(new JLabel("Name of the patient: \n"));
        add(new JTextField(10));
        add(new JLabel("Surname of the patient: \n"));
        add(new JTextField(10));
        add(new JLabel("Date of Birth: \n"));
        add(new JTextField(10));
        add(new JLabel("Mobile No: \n"));
        add(new JTextField(10));
        add(new JLabel("ID: \n"));
        add(new JTextField(10));
        add(new JButton("Enter"), BorderLayout.SOUTH);

        JButton button = new JButton("Enter");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

            }
        });
        panel.add(button);


    }

    public static void main(String[] args){
        AddingPatients frame = new AddingPatients();
        frame.setTitle("Adding Patients");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(500, 450);
        frame.setBackground(new Color(52, 23, 55));
        frame.setVisible(true);

        Button button3 = new Button();
        button3.setVisible(true);

    }
}
